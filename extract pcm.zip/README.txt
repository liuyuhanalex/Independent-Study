1. 说明
extra是提取人声的可执行文件，其依赖ffmpeg可执行文件。在执行extra时，必须保证ffmpeg在当前目录下。
  mac平台这两个工具位于bin/mac
  linux平台这两个工具位于bin/linux
  两个平台的可执行文件不通用

2. 使用
./extra ugc文件路径(.mp4) 伴奏文件路径(.m4a) 开始时间(ms) 输出文件路径 
参数：1 ugc文件路径
      2 伴奏文件路径
      3 相对伴奏播放，人声开始录制的时间，从服务器获取
      4 输出pcm文件路径。
  输出的pcm文件格式，float，单声道，32bit，44100采样率。
  提取失败，不会创建输出文件。

3. 举例
cd bin/mac/
#./extra ../../example/ugc.mp4 ../../example/acc.m4a 60 out.pcm 

4. 检查
执行
[mac]$ echo $?
0
[mac]$
输出0，即程序返回成功。会在当前目录下，生成out.pcm，其为提取的纯人声文件。

